<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style cars.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cars</title>
</head>
<body>
    <table border="1px">
        <tr>
        <th>S\N</th>
        <th>CAR TYPE</th>
        <th>DESCRIPTION </th>
        <th>PAYMENT METHODS</th>
    </tr>    
        <!-- FOR DIFFERENT  CARS -->
        
        <tr>
                <!-- for first car-->
            <td>1</td>
            <td><img src="IMG_20211005_093931.jpg"></td>
            <td>
                Price: 147,750<br> Name: FORD 2022 <br> Engine Size: 2,960cc<br> Gasoline: Petrol <br><br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
             <td> CASH <br><img src="cash.jpg"> </td>
        </td>
        </tr>

        <tr>
              <!-- for second car-->
            <td>2</td>
            <td><img src="Jeep.png"></td>
            <td>
                Price: 330,270 (ZMW)<br> Name: JEEP Grad Cherokee <br> Engine Size: 2,987cc<br> Gasoline: Diesel <br><br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
            <td> <img src="visa.jpg"> </td>
        </tr>

        <tr>
              <!-- for third car-->
            <td>3</td>
            <td><img src="images.jpg"></td>
            <td>
                Price: 130,500 (ZMW)<br> Name: TOYOTA Hilux<br> Engine Size: 2694cc<br> Gasoline: Petrol <br><br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
            <td> CASH <br><img src="cash.jpg"> </td>
        </tr>

    </table>
</body>

</html>