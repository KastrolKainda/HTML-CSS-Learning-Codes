<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style cars.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style shoes.css">
    <title>Shoes</title>
</head>
<body>
    <br>
    <h2> Shoe HomePage </h2>
    <br>
    <table border="1px">
        <tr>
        <th>S\N</th>
        <th>SHOE TYPE</th>
        <th>DESCRIPTION </th>
        <th>PAYMENT METHODS</th>
        </tr>

        <tr>
            <!--for first shoes-->
            <td> 1 </td>
            <td> <img src="Shoe 1.220x220.jpg"></td>
            <td>
                Price: 375.00 (ZMW)<br> Type: Male/Female - 1 pair <br> Size: Euro Size-42/43<br> Colour: Black <br> Heel style: Flat shoes<br> Pattern: Cotton inside <br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
            <td> CASH <br><img src="cash.jpg"> </td>
        </tr>

        <tr>
            <!--for second shoes-->
            <td> 2 </td>
            <td> <img src="Shoe 2.220x220.jpg"> </td>
            <td>
                Price: 450.00 (ZMW)<br> Type: Male - 1 pair <br> Size: Euro Size 40-43<br> Colour: Black/Brown/Meroon <br> Heel style: Flat shoes<br> Pattern: Leather <br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
            <td> CASH <br><img src="cash.jpg"> </td>
            </td>
            <td></td>
        </tr>

        <tr>
            <!--for third shoes-->
            <td> 3 </td>  
            <td><img src="Screenshot 2022-10-10 211630.png"> </td>
            <td>
                Price: 120 (ZMW)<br> Type: Male/female - 1 pair <br> Size: Euro Size 40-43<br> Colour: Black/Brown/Blue/Rose pink <br> Heel style: Flat shoes<br> Pattern: Leather&cotton <br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
            <td><img src="visa.jpg"> </td>
            </td>
            <td></td>
        </tr>
   
            
        
        

    

</body>
</html>