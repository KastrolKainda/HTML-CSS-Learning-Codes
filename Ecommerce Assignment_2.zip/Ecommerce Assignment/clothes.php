<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style cars.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Clothes </title>
</head>
<body>

    <h2> Clothes HomePage </h2>

    <table border="1px">
        <tr>
        <th>S\N</th>
        <th>CLOTHES TYPE</th>
        <th>DESCRIPTION </th>
        <th>PAYMENT METHODS</th>
    </tr>    
        <!-- FOR DIFFERENT  CARS -->
        
        <tr>
                <!-- for first Clothes-->
            <td> 1 </td>
            <td><img src="20221010_215935.jpg"></td>
            <td>
                Price: 1500 (ZMW)<br> Colours:black/ maroon/blue/brown <br> Fabric Type: cotton <br> Height:1.5/1.8 <br> Length:63/65/67 <br> Waist: 71/74/77 <br> Shoulder:41/42/43/44 <br> <br><br<br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
            </td>
             <td> CASH <br><img src="cash.jpg"> </td>
        </td>
        </tr>

        <tr>
              <!-- for second clothes-->
            <td> 2 </td>
            <td><img src="20221010_215951.jpg"></td>
            <td>
                Price: 1200 (ZMW)<br> Colours:black/yellow/navyblue/gray <br> Fabric Type:cotton <br> Height:1.5/1.7/1.8 <br> Length:63/65/67/69 <br>Waist:74/76/77 <br> Shoulder:41/42/44<br> <br><br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
               
            </td>
            <td> <img src="visa.jpg"> </td>
        </tr>

        <tr>
              <!-- for third clothes-->
            <td> 3 </td>
            <td><img src="20221010_220007.jpg"></td>
            <td>
                Price: 750 (ZMW)<br> Colours:white mixed with blue/white mixed with brown <br> Fabric Type: wax <br> Height:1.5/1.8/1.9 <br> Length:62/66/67 <br> Waist:74/76/69 <br> Shoulder:40/42/45/47<br> <br><br>
                <p>
                    <a href="#"> Get Quotation </a>
                </p>
                
            </td>
            <td> CASH <br><img src="cash.jpg"> </td>
        </tr>

    </table>
</body>

</html>